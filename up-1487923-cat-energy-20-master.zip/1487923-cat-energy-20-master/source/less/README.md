Папка для файлов препроцессора Less.

http://lesscss.org

--

Структура файлов:

less/
| - style.less
| - [другие *.less файлы]
